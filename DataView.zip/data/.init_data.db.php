<?php exit; ?>
{
    "modules": [
        {
            "id": "demo_module_1",
            "title": "示例模块",
            "description": "这是一个示例模块，您可以在后台管理中修改或删除它。",
            "columns": ["名称", "描述", "链接"],
            "rows": [
                {
                    "id": "row_1",
                    "data": ["示例项目1", "这是第一个示例项目的描述", "<a href=\"#\" target=\"_blank\">点击访问</a>"]
                },
                {
                    "id": "row_2",
                    "data": ["示例项目2", "<span style=\"color:#e74c3c\">支持HTML格式</span>", "<a href=\"#\" target=\"_blank\">点击访问</a>"]
                }
            ],
            "sort_order": 0
        }
    ],
    "settings": {
        "site_title": "数据展示系统",
        "updated_at": ""
    }
}
