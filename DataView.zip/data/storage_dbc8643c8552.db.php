<?php exit; ?>
{
    "modules": [
        {
            "id": "module_6959da6ddcdb6_de9afc74",
            "title": "测试测试测试测试测试测试测试测试测试测试测试测试",
            "description": "321321421421打撒打<br>dsadsada",
            "columns": [
                "1",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8"
            ],
            "rows": [
                {
                    "id": "row_6959da93c66d4_e281eba1",
                    "data": [
                        "哈哈哈哈哈哈哈哈",
                        "哈哈哈哈哈哈哈哈",
                        "哈哈哈哈哈哈哈哈",
                        "哈哈哈哈",
                        "哈哈哈哈",
                        "哈哈哈哈",
                        "哈哈哈哈",
                        "哈哈哈哈",
                        "哈哈哈哈"
                    ]
                }
            ],
            "sort_order": 0,
            "content_blocks": [
                {
                    "id": "block_6959fa1d3d214_c94056db",
                    "title": "内容块标题1",
                    "content": "哈哈哈哈哈哈哈哈哈<br>个嘎嘎嘎嘎嘎",
                    "position": "top",
                    "sort_order": 0
                },
                {
                    "id": "block_6959fa31193eb_97ce2d88",
                    "title": "标题2",
                    "content": "哈哈哈哈哈哈哈哈哈<br>嘎嘎嘎嘎嘎嘎嘎嘎",
                    "position": "top",
                    "sort_order": 1
                }
            ]
        }
    ],
    "settings": {
        "site_title": "服务器配置价目表",
        "updated_at": "2026-01-04 13:34:20"
    }
}