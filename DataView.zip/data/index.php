<?php
// 禁止直接访问此目录
http_response_code(403);
exit('Access Denied');
